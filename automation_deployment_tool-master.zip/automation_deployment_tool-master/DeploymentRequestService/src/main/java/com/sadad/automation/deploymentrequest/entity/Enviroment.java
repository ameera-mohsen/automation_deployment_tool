package com.sadad.automation.deploymentrequest.entity;

public class Enviroment {

	private String name;
	private String cluster;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}



}

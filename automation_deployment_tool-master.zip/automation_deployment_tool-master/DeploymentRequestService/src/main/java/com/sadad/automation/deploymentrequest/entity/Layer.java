package com.sadad.automation.deploymentrequest.entity;

public class Layer {

	
	private String name;
	
	private String details;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}


}

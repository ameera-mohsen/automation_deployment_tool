package com.dxc.automation.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface GroupService extends UserDetailsService {

}




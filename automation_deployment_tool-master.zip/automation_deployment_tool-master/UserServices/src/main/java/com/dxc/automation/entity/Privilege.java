package com.dxc.automation.entity;

public class Privilege {

	private int level;

	public Privilege() {
	}

	public Privilege(int level) {
		super();
		this.level = level;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
